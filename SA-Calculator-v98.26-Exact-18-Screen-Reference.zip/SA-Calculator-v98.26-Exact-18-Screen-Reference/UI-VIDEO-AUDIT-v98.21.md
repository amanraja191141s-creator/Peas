# SA Calculator v98.21 — recording inspection and corrective release

## What the supplied 26.19-second recording actually shows
- The Settings → About & Support screen visibly reports `v1.98.19-v98.19`. This is not the v98.20 source release; it establishes that the recorded/installed app was an older APK.
- The calculator screen still shows the old toolbar (brand mark plus FX/clock/settings actions), a clipped skip-link overlay, an empty first key, parentheses instead of the +/- key, and a narrow equals key.
- The drawer is still the older large-row list rather than the compact five-category grouped drawer.
- The Favorites screen is still the older large-card layout.

## Source-vs-installed mismatch
The inspected v98.20 source ZIP declares `1.98.20-v98.20` in `package.json`, `index.html`, the runtime `APP_VERSION`, and the manifest. Its calculator markup has the reference key order (`AC`, `+/−`, `%`, `÷`; 7–9/×; 4–6/−; 1–3/+; 0/decimal/equals) and its CSS stretches keys across the grid. The recording reports v98.19, so it cannot be used as proof that v98.20 source changes reached the device.

## v98.21 corrective release
- Carries forward the v98.20 reference redesign without removing scientific functions, history, memory, currency, settings or tool calculators.
- Prevents a touch-focused skip link from overlaying the app toolbar on Android touch devices while retaining keyboard-visible accessibility behaviour.
- Bumps the visible app version and Android versionCode so the newly built APK is distinguishable from the older installed app.
- Makes the workflow reject any selected source other than exactly `1.98.21-v98.21`.
- Makes the workflow inspect APK badging and fail unless versionName is `1.98.21-v98.21` and versionCode is `1098021`.

## Install verification required
Download the artifact named `SA-Calculator-Debug-APK-1.98.21-v98.21`. Install that APK, open Settings → About & Support and confirm `v1.98.21-v98.21`. If it still reports v98.19, the old app is still running or the wrong artifact was installed. Compare UI only after confirming the version.
