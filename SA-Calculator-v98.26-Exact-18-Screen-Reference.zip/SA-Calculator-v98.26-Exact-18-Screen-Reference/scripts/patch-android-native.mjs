import { cp, mkdir, readFile, readdir, writeFile, access } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const android = path.join(root, 'android');
const res = path.join(android, 'app', 'src', 'main', 'res');
await access(path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml'));

// Replace generated Capacitor launcher icons with the same verified brand artwork.
const iconRoot = path.join(root, 'assets', 'brand', 'android-icons');
for (const dir of await readdir(iconRoot, { withFileTypes: true })) {
  if (!dir.isDirectory() || !/^mipmap-(?:mdpi|hdpi|xhdpi|xxhdpi|xxxhdpi)$/.test(dir.name)) continue;
  const targetDir = path.join(res, dir.name);
  await mkdir(targetDir, { recursive: true });
  for (const file of ['ic_launcher.png', 'ic_launcher_round.png']) {
    const source = path.join(iconRoot, dir.name, file);
    await access(source);
    await cp(source, path.join(targetDir, file));
  }
}
await mkdir(path.join(res, 'drawable'), { recursive: true });
await cp(path.join(iconRoot, 'drawable', 'ic_launcher_foreground.png'), path.join(res, 'drawable', 'ic_launcher_foreground.png'));
await mkdir(path.join(res, 'values'), { recursive: true });
await writeFile(path.join(res, 'values', 'ic_launcher_background.xml'), '<resources><color name="ic_launcher_background">#03132f</color></resources>\n');
await mkdir(path.join(res, 'mipmap-anydpi-v26'), { recursive: true });
const adaptive = `<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background" />\n    <foreground android:drawable="@drawable/ic_launcher_foreground" />\n</adaptive-icon>\n`;
await writeFile(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher.xml'), adaptive);
await writeFile(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher_round.xml'), adaptive);

// Android 15+ enforces edge-to-edge for targetSdk 35. A theme color alone is
// not sufficient: inset the actual Capacitor content view for status bar,
// navigation bar and display cutouts, while keeping system icons high contrast.
let appGradle = await readFile(path.join(android, 'app', 'build.gradle'), 'utf8').catch(() => '');
let appGradleKts = await readFile(path.join(android, 'app', 'build.gradle.kts'), 'utf8').catch(() => '');
const packageJson = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
const versionName = String(packageJson.version || '');
const semver = versionName.match(/^(\d+)\.(\d+)\.(\d+)/);
if (!semver) throw new Error(`Invalid app version for Android packaging: ${versionName}`);
const versionCode = Number(semver[1]) * 1000000 + Number(semver[2]) * 1000 + Number(semver[3]);
if (!Number.isSafeInteger(versionCode) || versionCode < 1 || versionCode > 2100000000) throw new Error(`Android versionCode is outside the supported range: ${versionCode}`);
if (appGradle) {
  const block = appGradle.match(/(defaultConfig\s*\{)([\s\S]*?)(\n\s*\})/);
  if (!block) throw new Error('Unable to locate defaultConfig in android/app/build.gradle');
  let body = block[2];
  body = /^\s*versionCode\s+\d+\s*$/m.test(body) ? body.replace(/^\s*versionCode\s+\d+\s*$/m, `        versionCode ${versionCode}`) : `${body}\n        versionCode ${versionCode}`;
  body = /^\s*versionName\s+[\"'][^\"']*[\"']\s*$/m.test(body) ? body.replace(/^\s*versionName\s+[\"'][^\"']*[\"']\s*$/m, `        versionName \"${versionName}\"`) : `${body}\n        versionName \"${versionName}\"`;
  appGradle = appGradle.replace(block[0], `${block[1]}${body}${block[3]}`);
  await writeFile(path.join(android, 'app', 'build.gradle'), appGradle);
} else if (appGradleKts) {
  const block = appGradleKts.match(/(defaultConfig\s*\{)([\s\S]*?)(\n\s*\})/);
  if (!block) throw new Error('Unable to locate defaultConfig in android/app/build.gradle.kts');
  let body = block[2];
  body = /^\s*versionCode\s*=\s*\d+\s*$/m.test(body) ? body.replace(/^\s*versionCode\s*=\s*\d+\s*$/m, `        versionCode = ${versionCode}`) : `${body}\n        versionCode = ${versionCode}`;
  body = /^\s*versionName\s*=\s*[\"'][^\"']*[\"']\s*$/m.test(body) ? body.replace(/^\s*versionName\s*=\s*[\"'][^\"']*[\"']\s*$/m, `        versionName = \"${versionName}\"`) : `${body}\n        versionName = \"${versionName}\"`;
  appGradleKts = appGradleKts.replace(block[0], `${block[1]}${body}${block[3]}`);
  await writeFile(path.join(android, 'app', 'build.gradle.kts'), appGradleKts);
} else {
  throw new Error('Android app Gradle file is missing; cannot set a safe upgrade version.');
}
const namespace = (appGradle.match(/namespace\s+["']([^"']+)["']/) || appGradleKts.match(/namespace\s*=\s*["']([^"']+)["']/) || [])[1];
if (!namespace) throw new Error('Unable to determine Android app namespace for safe MainActivity generation.');
const javaDir = path.join(android, 'app', 'src', 'main', 'java', ...namespace.split('.'));
await mkdir(javaDir, { recursive: true });
const mainActivity = `package ${namespace};

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

/** Applies stable Android system-bar insets to the Capacitor WebView host. */
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setStatusBarContrastEnforced(false);
            getWindow().setNavigationBarContrastEnforced(false);
        }
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(2, 7, 19));
        WindowInsetsControllerCompat bars = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (bars != null) {
            bars.setAppearanceLightStatusBars(false);
            bars.setAppearanceLightNavigationBars(false);
        }
        final View content = findViewById(android.R.id.content);
        if (content != null) {
            final int left = content.getPaddingLeft();
            final int top = content.getPaddingTop();
            final int right = content.getPaddingRight();
            final int bottom = content.getPaddingBottom();
            ViewCompat.setOnApplyWindowInsetsListener(content, (view, windowInsets) -> {
                Insets safe = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout()
                );
                view.setPadding(left + safe.left, top + safe.top, right + safe.right, bottom + safe.bottom);
                return windowInsets;
            });
            ViewCompat.requestApplyInsets(content);
        }
    }
}
`;
await writeFile(path.join(javaDir, 'MainActivity.java'), mainActivity);

// Keep a dark fallback window surface and light system icons on pre-Android 15.
const valuesDirs = (await readdir(res, { withFileTypes: true }))
  .filter(entry => entry.isDirectory() && entry.name.startsWith('values'))
  .map(entry => path.join(res, entry.name));
let patched = 0;
for (const dir of valuesDirs) {
  for (const file of await readdir(dir)) {
    if (!file.endsWith('.xml')) continue;
    const full = path.join(dir, file);
    let xml = await readFile(full, 'utf8');
    if (!/<style\b[^>]*name="AppTheme(?:\.[^"]+)?"/.test(xml)) continue;
    xml = xml.replace(/(<style\b[^>]*name="AppTheme(?:\.[^"]+)?"[^>]*>)([\s\S]*?)(<\/style>)/g, (whole, open, body, close) => {
      const items = [
        ['android:windowDrawsSystemBarBackgrounds', 'true'],
        ['android:statusBarColor', '#020713'],
        ['android:windowLightStatusBar', 'false'],
        ['android:navigationBarColor', '#020713'],
        ['android:windowLightNavigationBar', 'false'],
        ['android:windowActionModeOverlay', 'true'],
        ['android:windowBackground', '#020713']
      ];
      if (/Launch/i.test(open)) {
        items.push(['android:windowSplashScreenBackground', '#020713']);
        items.push(['android:windowSplashScreenAnimatedIcon', '@mipmap/ic_launcher']);
      }
      let next = body;
      for (const [name, value] of items) {
        const tag = `<item name="${name}">${value}</item>`;
        const re = new RegExp(`<item\\s+name="${name.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')}"[^>]*>[\\s\\S]*?<\\/item>`);
        if (re.test(next)) next = next.replace(re, tag);
        else next += `\n        ${tag}`;
      }
      return `${open}${next}\n    ${close}`;
    });
    await writeFile(full, xml);
    patched++;
  }
}
if (!patched) throw new Error('No AppTheme style found; cannot apply Android system-bar styling safely.');
console.log(`Android branding applied: launcher icons copied; app version ${versionName} (versionCode ${versionCode}); edge-to-edge MainActivity generated for ${namespace}; ${patched} theme XML file(s) patched.`);
