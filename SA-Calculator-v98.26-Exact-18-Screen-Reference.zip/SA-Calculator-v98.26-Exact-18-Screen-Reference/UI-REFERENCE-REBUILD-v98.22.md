# SA Calculator v98.23 — Reference UI rebuild

## Exact reference target used
The supplied 4×2 Android reference montage is the design source: dark navy surfaces, compact title bars, four-column calculator keypad, grouped compact drawer, blue primary actions, green result cards, and the specific Sales Tax, Loan, Tip, Unit Price, World Time and Settings layouts.

## Replaced visible legacy compositions
- Calculator: removed the always-visible scientific/memory strip from the primary keypad view; retained scientific/history entry points in the navigation drawer and preserved the 4×5 keypad interaction sequence.
- Sales Tax: Item Price + Sales Tax Rate, Calculate action, green Sales Tax and Total Price result card.
- Loan: Loan Amount, Annual Interest Rate, Loan Term in years, Calculate action, monthly payment/total payment/interest results and amortization schedule. Existing amortization engine is retained; years are converted to months.
- Tip: Bill Amount, 10/15/20/custom percentage presets, green Tip Amount and Total Amount result card. Existing split/tax inputs remain internally available but are not part of the primary reference layout.
- Unit Price: two-item price/quantity comparison, Compare action and Better Deal result. Existing extra comparison fields remain hidden for compatibility.
- World Time: globe hero, city search/add and two-column live city cards.
- Navigation: compact bottom four-tab navigation and categorized slide-out tools drawer retained.
- Settings: existing setting IDs and handlers retained, with reference dark theme styling and compact row treatment.

## Verification boundaries
Local source regression and static validation are required before packaging. GitHub-hosted APK build and physical Android screenshot verification remain external release gates; no universal zero-bug claim is made without device testing.
