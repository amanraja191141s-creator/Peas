const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.join(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('Capacitor Android wrapper is configured for a local offline web bundle', () => {
  const config = JSON.parse(read('capacitor.config.json'));
  assert.equal(config.appId, 'com.sacalculator.app');
  assert.equal(config.appName, 'SA Calculator');
  assert.equal(config.webDir, 'www');
  assert.equal(config.server.androidScheme, 'https');
  assert.equal(config.android.allowMixedContent, false);
});

test('Android build workflow locates or extracts the app root before running npm', () => {
  const workflow = read('.github/workflows/main.yml');
  const hasLocatorId = /id: (locate|source)\b/.test(workflow);
  assert.ok(hasLocatorId, 'Workflow must expose a project-root output before npm runs');
  assert.match(workflow, /find .*package\.json|package\.json/);
  assert.match(workflow, /working-directory: \$\{\{ steps\.(locate|source)\.outputs\.app_dir \}\}/);

  for (const expected of [
    'npm install --no-audit --no-fund',
    'npm test',
    'npm run build:web',
    'npx cap add android',
    'npx cap sync android',
    'assembleDebug',
    'actions/upload-artifact@v4',
    'app-debug.apk'
  ]) {
    assert.ok(workflow.includes(expected), `Missing Android build configuration: ${expected}`);
  }

  assert.match(workflow, /expected exactly one app package\.json|Expected exactly one application package\.json/);
  assert.match(workflow, /No valid SA Calculator project found|package\.json (was not found|missing)|No package\.json|Expected exactly one application package\.json/);
});

test('Android web bundle builder verifies all runtime assets before copying', () => {
  const script = read('scripts/prepare-android-web.mjs');
  for (const asset of ['index.html', 'assets/css/app.css', 'assets/js/app.js', 'assets/js/localization.js', 'assets/js/currency-localized-names.js', 'assets/js/theme-bootstrap.js', 'assets/brand/sa-calculator-icon.png', 'assets/brand/sa-calculator-192.png', 'assets/brand/sa-calculator-512.png', 'service-worker.js']) {
    assert.ok(script.includes(asset), `Missing required web asset: ${asset}`);
  }
});


test('Android web bundle contains the registered service worker and its precache dependencies', () => {
  const result = spawnSync(process.execPath, ['scripts/prepare-android-web.mjs'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr || result.stdout);
  const out = path.join(root, 'www');
  assert.equal(fs.existsSync(path.join(out, 'service-worker.js')), true, 'service-worker.js must be shipped beside index.html');
  const sw = fs.readFileSync(path.join(out, 'service-worker.js'), 'utf8');
  const list = sw.match(/const ASSETS=\[(.*?)\];/s);
  assert.ok(list, 'bundled service worker must contain its precache list');
  for (const [, asset] of list[1].matchAll(/'([^']+)'/g)) {
    const local = asset === './' ? 'index.html' : asset.replace(/^\.\//, '');
    assert.equal(fs.existsSync(path.join(out, local)), true, `bundled precache asset missing: ${asset}`);
  }
});


test('only one active GitHub Actions workflow exists and the supplied root copy matches it', () => {
  const main = read('.github/workflows/main.yml');
  const embedded = read('android-apk.yml');
  assert.equal(main, embedded, 'The root android-apk.yml reference copy must match the active main.yml');
  assert.equal(fs.existsSync(path.join(root, '.github/workflows/android-apk.yml')), false, 'A duplicate active workflow can launch a second confusing APK build');
  assert.match(main, /id: locate\b/);
  assert.match(main, /Run complete regression tests[\s\S]*?run: npm test/);
  assert.match(main, /Build Android debug APK[\s\S]*?assembleDebug/);
  assert.match(main, /actions\/upload-artifact@v4/);
});


test('Android workflow syntax-checks the native inset and branding patch before build', () => {
  const workflow = read('.github/workflows/main.yml');
  assert.match(workflow, /node --check scripts\/patch-android-native\.mjs/);
  assert.match(workflow, /www\/assets\/brand\/sa-calculator-192\.png/);
  assert.match(workflow, /www\/assets\/brand\/sa-calculator-512\.png/);
  assert.match(workflow, /Apply premium Android launcher icon, splash theme and edge-to-edge insets[\s\S]*?npm run android:brand/);
});


test('Android workflow selects only the exact expected package version and prefers its source ZIP', () => {
  const workflow = read('.github/workflows/main.yml');
  assert.match(workflow, /Select the exact v98\.26 source archive or extracted project root/);
  assert.match(workflow, /exactCandidates = candidates\.filter/);
  assert.match(workflow, /Prefer the exact-version source ZIP/);
  assert.match(workflow, /Selected exact v98\.26 source archive/);
  assert.match(workflow, /index\.html does not declare package version/);
  assert.match(workflow, /SA-Calculator-Debug-APK-\$\{\{ steps\.locate\.outputs\.app_version \}\}/);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.26-v98\.26'/);
  assert.match(workflow, /Wrong\/stale source selected/);
  assert.match(workflow, /versionName='1\.98\.26-v98\.26'/);
  assert.match(workflow, /versionCode='1098026'/);
});
