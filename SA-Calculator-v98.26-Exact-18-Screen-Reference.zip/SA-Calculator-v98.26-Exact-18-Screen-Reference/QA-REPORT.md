# SA Calculator v92 — QA and whole-app feature audit

Current release: `1.97.2-v97.2`

Historical v91 audit notes below are retained for traceability; the current release verification is in `RELEASE-VERIFICATION.md`.  
Scope: currency reliability completion plus review of all calculator tools, settings, themes, history, navigation, help/feedback, storage and release assets.

## Previous v87 fixes retained

### Currency engine

- Currency selector now matches the supplied video with a fixed 105-row curated list, sorted by full currency name, with full names, ISO codes, selected checkmark, search and A–Z quick navigation. It does not append provider-only or accounting/metal/test codes.
- Known withdrawn currency codes (including SVC) and non-circulating fund, metal and technical units are filtered. The static list is a safeguard and still requires periodic sync against the official ISO 4217 registry.
- public currency provider fallback accepts a single valid selected-pair quote (not an arbitrary ten-rate minimum), validates the quote's USD base and expected target, and requires a valid observation date.
- public currency provider is queried only when the same-origin server status endpoint reports that a server-side API key is configured. No API key is shipped to the client. If no key is configured, the optional provider is skipped rather than repeatedly hitting a known-disabled endpoint.
- The proxy exposes a non-secret enabled/disabled status, loads optional `.env` configuration without a dependency (process environment takes precedence), forwards upstream `Retry-After`, and returns a cooldown header when disabled or locally rate-limited. `.env` is ignored by Git and blocked by the static file server. public currency provider's documented free-tier quota/key errors trigger a 24-hour cooldown; unsupported target codes are cooled down separately to avoid repeated invalid requests.
- Same-date observations from different providers no longer silently replace the already-selected provider's rate. Source provenance is updated only for codes accepted by the merge.
- Fawaz/Open ER-API have a four-day freshness ceiling; public currency provider has a three-day ceiling; Frankfurter validates each row independently with a ten-day ceiling. Cached old observations are labelled as older in the selected-pair note.
- Pair observation dates use the older date of the two required currencies. USD-base pairs use the quote currency's date; same-currency conversions do not display an unrelated FX date.
- Currency amount display follows ISO minor-unit digits and half-up rounding; the grouping separator follows the user's number-format setting. Internal decimal-string calculation remains separate from the rounded display.
- Open ER-API attribution is keyed to the selected pair's actual provider provenance, including cached/offline display.
- Partial-pair retry uses bounded exponential backoff with jitter, honours provider cooldowns, and does not refresh early while a retry timer is still pending. Network recovery still triggers an immediate retry.

### Settings, themes and language

- Fixed settings initialization persistence: apply handlers could save partially restored defaults over preferences that had not yet loaded. Settings are now saved once after the complete settings record has been restored and normalized.
- Appearance Mode (Light/Dark/Follow System) is now a visible select. The 15-option accent palette picker is labelled separately, so it no longer masquerades as the theme-mode selector.
- Fullscreen state follows the actual browser `fullscreenchange` event and reverts correctly if fullscreen is unavailable or exited by the user.
- Screen wake lock toggles revert if the API is unsupported or permission is denied.
- Navigation language updates the document language metadata and accessible drawer labels without replacing the drawer's labelled title element. The UI explicitly states that only navigation labels/titles are translated; tool instructions remain English.
- Startup restoration suppresses success toasts from apply handlers, avoiding theme/font/OLED popups on every app launch.

### History, help and feedback

- History uses a central record function. If all configured slots are protected, a new result is not silently discarded; the user is told to unlock an entry or raise the limit.
- The lock action prevents protecting more entries than the configured maximum. Protected entries are not silently evicted by normal retention.
- Help and Feedback & Bug Report are real accessible local dialogs, not placeholder toasts. Feedback is only copied/shared after explicit user action; no report is uploaded automatically.
- The Help guide clarifies that History records standard calculator expressions/results. Tool-specific form values are not part of the History list.
- The destructive privacy action is labelled “Clear App Data & Cache” and explains that local settings, history, memory, saved inputs and browser cache are removed.

## Complete feature inventory audited

### Calculator/tools — 17 screens

1. Standard Calculator — arithmetic, scientific functions, memory, live preview, DEG/RAD, physical/popup keypad.
2. Currency Converter — currency pair selection, amount input, swap, manual/automatic refresh, dated provider rates, offline cache/estimate labels.
3. Unit Converter — category and source/destination unit selection, temperature/fuel/data and other dimensional conversions.
4. Discount Calculator — original price, discount, added tax, savings and final price.
5. Percent Calculator — percentage change and percentage-of-value modes.
6. Sales Tax Calculator — exclusive and inclusive tax modes.
7. Body Metrics — BMI and Mifflin-St Jeor BMR with input validation.
8. Date Calculator — local date reminders/anniversaries, repeat, edit, delete and persistence.
9. Fuel Cost — distance, efficiency, fuel price, fuel use and cost.
10. Fuel Efficiency — fill-to-fill consumption, km/L, L/100 km and US mpg.
11. Grade Average — dynamic subjects, credits, grade points and local persistence.
12. Number Base Converter — synchronized HEX/DEC/OCT/BIN using BigInt.
13. Loan/EMI — equal total/equal principal methods, interest-only grace period and amortization schedule.
14. Savings — simple/compound frequencies and tax on interest.
15. Tip — bill, tip percentage, people split, tax amount and pre-tax tip option.
16. Unit Price — up to four products, per-unit calculation and lowest-price tie handling.
17. World Time — IANA time-zone search, live clocks and local saved city selection.

### Navigation and personalization

- Drawer registers all 17 tool screens; Settings is separate.
- Favorites manager supports all tool screens and reset-to-default favorites.
- Startup preference and restore-previous-input preference are present.
- Screen changes update the active drawer item and header title.

### Settings — 12 groups

1. Appearance — font size, fullscreen for current session, keep screen awake for current session.
2. Theme & Colors — Light/Dark/Follow System mode, 15 named accent palettes, accent color selector, OLED pure black.
3. Calculator Settings — DEG/RAD, instant preview, implicit multiplication.
4. Decimal & Number Format — Auto/0/2/4/6 precision, comma/space/lakh/none grouping, trailing zeros.
5. Navigation Language — English, Hindi, Urdu, Spanish, French, German, Arabic, Chinese; navigation labels/titles only.
6. Startup Preferences — startup screen, restore previous values.
7. Favorites Management — checklist for 17 tools, reset favorites.
8. History Settings — record toggle, 25/50/100/500 limit, clear unlocked entries.
9. Clipboard & Copy — auto-copy calculator results.
10. Sound & Vibration — key sound, haptic feedback, intensity.
11. Privacy — diagnostics disabled, local calculation indicator, Clear App Data & Cache.
12. About & Support — version, independent-product status, Help guide, Feedback/Bug Report, Reset All Settings.

### Theme and layout

- 15 named accent palettes plus a separate accent-color selector.
- Light, dark and system-following appearance modes.
- OLED black mode and semantic status colors.
- Shared number formatter respects precision, trailing-zero and grouping preferences. Currency display additionally follows ISO currency minor units.

### History

- Persistent local standard-calculator expression/result history (subject to browser storage availability).
- Actions: Copy; Reuse/Edit; Share; Name/Rename; Protect/Unlock; Delete unlocked.
- Clear history removes unlocked entries and preserves protected entries.
- Retention options: 25, 50, 100, 500. If every slot is protected, recording/locking is blocked with an explanation.
- Tool-specific form inputs are not recorded in History.

## Static integration audit

- 18 screen containers: 17 calculator screens plus Settings.
- All 17 calculator screens match the favorites/menu registry.
- All distinct HTML `data-action` names map to JavaScript handlers.
- HTML IDs are unique; literal `getElementById` references are checked against the document or marked optional by tests.
- Theme palette count, settings groups, runtime assets, manifest, logo, server and service-worker references are release-gated.

## Automated verification

Command: `npm test`  
Final result: **56 tests passed, 0 failed**.

Coverage includes:
- JavaScript syntax, scientific parser and arithmetic rejection cases.
- Currency cache per-row dates, invalid/stale/future data, older response protection, same-date provider conflict behavior, selected-pair dates, source provenance, Retry-After parsing, cross-currency USD-base ratio math in both directions, ISO minor-unit rounding, all grouping modes, public currency provider selected-quote validation, currency catalogue exclusions and currency swap raw-value synchronization.
- Settings preference restoration and regression for save-during-load overwrite, enum validation, visible appearance mode, navigation language/accessibility metadata.
- History record retention, restore sanitization, protected-entry handling and full-protection behavior.
- Representative finance/tool formulas: discount, percent, sales tax, BMI/BMR, fuel cost, fuel efficiency, savings, tip, unit price, loan amortization, unit conversion, leap-day validation, hexadecimal BigInt and world-time date formatting.
- All tool screens and HTML action-handler registry, unique IDs, static asset presence, CSS structure, service-worker API cache exclusion and server route/security behavior.

## Not verified / manual release gates

- Interactive browser end-to-end testing across all screens was not executed in this build environment; HTML/CSS parsing and automated logic/server tests were run instead.
- Live API uptime and payload compatibility at every future date; all possible currency-pair coverage; source rates are not executable bank/card/remittance prices.
- Physical Android System WebView matrix, low-memory devices, touch/caret behavior, keyboard/IME behavior, orientation, background/foreground lifecycle, screen wake lock and fullscreen behavior on actual devices.
- Accessibility audit with TalkBack/screen readers and real keyboard navigation on each screen.
- Performance profiling for long sessions, memory growth and repeated navigation on low-end Android devices.
- Signed APK generation, installation, upgrade from older APKs, offline install and Play Store review.
- Trademark availability, legal clearance, complete source provenance and third-party licence audit.

No claim of zero defects, live provider guarantee, Android device certification or legal clearance is made.

## Currency-code references

- SIX, official ISO 4217 Maintenance Agency and currency/fund lists: https://www.six-group.com/en/products-services/financial-information/market-reference-data/data-standards.html
- SIX ISO 4217 Amendment 176 (XCG/ANG): https://www.six-group.com/dam/download/financial-information/data-center/iso-currrency/amendments/dl-currency-iso-amendment-176.pdf
- SIX ISO 4217 Amendment 180 (BGN historical from 2026-01-01): https://www.six-group.com/dam/download/financial-information/data-center/iso-currrency/amendments/dl-currency-iso-amendment-180.pdf
- Frankfurter API documentation: https://frankfurter.dev/
- ExchangeRate-API Open Access documentation: https://www.exchangerate-api.com/docs/free


## v88 — Currency refresh time display

- Added a persistent **Last checked** timestamp, updated after every completed automatic, manual, foreground-resume, network-recovery, and scheduled retry attempt.
- Added a separate **Rates last updated** timestamp, updated only after a successful provider refresh. Failed refreshes preserve the previous successful timestamp.
- Both timestamps render in the user's device-local date/time format and timezone, with seconds for precise refresh timing.
- Persisted metadata separately from the rates cache so failed attempts are also retained across app restarts.
- Migrates older v87 cached-success time when dedicated metadata is not present. Invalid and future timestamps are rejected.
- Added dedicated tests for timestamp rendering, failed-attempt persistence, v87 metadata migration, and invalid/future timestamp rejection.
- This display time represents when the app checked/refreshed, not the provider's rate observation date.


## v89 — Newest dated provider observations

- Fixed provider short-circuit: complete Fawaz data no longer prevents newer dated independent providers from being checked.
- Frankfurter v2 is evaluated first, then Open ER-API and Fawaz as public fallbacks.
- Existing per-currency merge policy continues to reject older observation dates; selected-pair date is derived from the older leg, not the app refresh time.
- This does not manufacture intraday rates. If all providers publish only the prior date, the UI must truthfully show that provider observation date while showing the current local refresh timestamp separately.


## Reference video currency-picker verification

- Inspected the supplied 24.56-second screen recording and implemented its alphabetical full-screen selection pattern.
- The curated option set contains 105 unique currency codes; tests assert the count, uniqueness, inclusion of the video-visible entries, and exclusion of common non-fiat/accounting/metal/test codes.
- Search filters by both currency name and code. A–Z quick navigation is generated from the visible result set and hidden while searching.
- Selection updates the existing converter selectors through their standard change handlers, so rate refresh and calculation behavior remain connected.
- Visual/interaction automation on a physical Android device remains a manual QA item; passing Node tests do not prove device-level rendering or touch behavior.

## v89.2 selected currency pair persistence
- The selected From/To ISO currency codes are stored separately from exchange-rate data.
- The selected pair is restored on app startup and remains unchanged when providers refresh numeric rates.
- Manual selection, picker selection (through the same change event), and Swap all persist the pair.
- Invalid or unavailable local storage safely falls back to the default CNY → INR pair; malformed or unknown codes are rejected.
- Added regression tests proving rate-value changes do not change the selected ISO codes.
- Automated regression suite: 56 passed, 0 failed.

## v89.1 screenshot-requested currency display cleanup
- Hidden the visible provider/status/refresh timestamp rows and attribution link marked in the user's screenshot; underlying refresh and metadata code remains active.
- Applied slightly larger/heavier typography to currency screen labels, codes, values, rate note and keypad controls.
- Regression suite after changes: 54/54 passed, 0 failures.
- Manual testing on physical Android hardware remains outstanding.


## v1.90.0-v90 header and settings regression
- Added a text-only fixed SA Calculator header brand across screens and languages.
- Removed the in-header logo element only; PWA/launcher icon assets remain available.
- Added regression coverage for header branding and all 12 settings groups/control IDs.
- Full test suite result is recorded in RELEASE-VERIFICATION.md.


## v90.1 header title correction
- Basic calculator header title: `SA Calculator`.
- Other calculator/tool/settings screens: their own translated names.
- Drawer brand remains `SA Calculator`; header logo remains absent.
- Language switch updates the title for the currently active screen.
- Service-worker cache key bumped to invalidate the previous shell.
- Regression result: 58 passed, 0 failed.


## v91 whole-project regression audit (2026-11-13)

- Re-ran all 58 inherited tests. 56 passed and two release-gate assertions failed because the expected service-worker cache key was stale (`sa-calculator-v90-shell`) while the shipped worker used a versioned `sa-calculator-v90-1-screen-titles-shell` key.
- Corrected both assertions to the new v91 cache key and added a dedicated feedback-report version regression test.
- Fixed two stale hard-coded v87 feedback-report version strings by using the single current `APP_VERSION` constant.
- Synchronized package/manifest/HTML/Settings/server metadata and service-worker cache version to `1.91.0-v91`.
- Updated stale documentation that incorrectly described the header as `SA Calculator` on every screen; only Basic Calculator uses the product name, while other screens use their own titles.
- JavaScript syntax checks and full automated tests are run again for this release. Physical Android/WebView, live provider and device performance testing remain manual release gates.

## v91 final automated result

- `npm test`: **59 passed, 0 failed, 0 skipped**.
- `node --check`: `assets/js/app.js`, `server.js`, and `service-worker.js` all passed.
- HTML parser check: 231 IDs, no duplicate IDs; the HTML shell references the expected local JS, CSS, manifest and icon assets.
- ZIP integrity is verified after packaging.
- Remaining manual gates are explicitly listed in `RELEASE-VERIFICATION.md`.


## v92 unit-converter scientific display verification

- Fixed the Unit Converter's primary result formatter: ordinary grouped output is retained through 12 integer digits; 13-digit-and-larger values use 12-significant-digit scientific notation.
- Example from the supplied screenshot: `81,064,793,292,700,000` now displays as `8.10647932927e+16`.
- Very small non-zero values use scientific notation to avoid misleading zero display; zero remains `0`; non-finite values are rejected as `Error`.
- Conversion calculations and underlying numeric values are unchanged; only the displayed result string changes.
- Added two focused tests covering the numeric boundary and actual Unit Converter formatter wiring.
- Release version: `1.92.1-v92`; service-worker cache: `sa-calculator-v92-1-92-1-glitch-fix-shell`.
- Final automated suite: 61 tests passed, 0 failed.


## v92 global public currency API update (2026-11-13)

- Removed the private Cloudflare Worker package, private SA Currency API adapter/configuration, and the optional server-keyed Xurrency proxy.
- Configured Frankfurter v2 as the primary public global reference-rate API, with Open ER-API and Fawaz Exchange API fallbacks.
- Kept per-currency observation-date validation, freshness-aware merge, selected-pair persistence, local cache, offline estimates and refresh status.
- Bumped the service-worker cache key to `sa-calculator-v92-1-92-1-glitch-fix-shell` so installed PWAs fetch the changed application code.
- Automated suite: 63 passed, 0 failed.
- JavaScript syntax checks passed for app.js, server.js and service-worker.js.
- Live upstream availability and physical Android/WebView behaviour remain device/network checks; this build environment cannot verify them.


## v1.92.1-v92 video issue verification

- Theme first-paint bootstrap is loaded before the main CSS and included in the service-worker precache.
- Toast placement no longer overlaps the bottom keypad row.
- Manual currency refresh has a five-second rapid-tap guard; background refresh is silent.
- Automated regression suite: 63 passed, 0 failed.


## v1.92.7-v92 release-polish audit (2026-11-13)

- Final automated suite: **65 passed, 0 failed, 0 skipped**.

- Reconciled stale audit inventory entries that incorrectly described a private Cloudflare Worker, server-side currency proxy, `.env.example`, and v91 runtime cache identity as part of the current public-provider package.
- Added `role="status"`, `aria-live="polite"` and `aria-atomic="true"` to the transient app toast so success/error feedback can be announced accessibly without stealing focus.
- Advanced app/package/manifest/feedback metadata and service-worker cache identity to `1.92.7-v92`.
- Re-ran the full Node test suite and release checks; see the current exact result in `RELEASE-VERIFICATION.md`.
- Physical Android/WebView interaction, visual viewport checks and live provider availability remain manual verification items.

## v1.92.7-v92 deep-audit clean release (2026-11-13)

- Re-ran the complete regression suite from the latest hard-polished archive.
- Added two additional release gates for mobile viewport/safe-area/narrow-screen/reduced-motion support and the static server's currency-provider CSP allowlist.
- Synchronized package, manifest, HTML title, app feedback version, Settings version and service-worker cache namespace to `1.92.7-v92`.
- Existing calculator, history, settings, theme, navigation, currency-provider fallback, offline-cache, toast-placement and refresh-throttling code was retained.
- `npm test`: **67 passed, 0 failed, 0 skipped**.
- `node --check` passed for app.js, theme-bootstrap.js, server.js and service-worker.js.
- Local HTTP smoke checks passed as part of the suite; ZIP integrity is verified after packaging.
- Real Android/Acode visual and touch testing, landscape checks and live provider availability remain manual gates.


## v1.92.7-v92 currency refresh and metadata correction (2026-11-13)
- Current suite after this release: 75 passed, 0 failed, 0 skipped.
- Moved the manual refresh control out of the global app header and into the Currency Converter screen.
- Refresh feedback now counts only selectable catalogue currencies with valid rates, not all extra provider response keys.
- Normalized Frankfurter provider attribution to a stable short label; provider metadata objects are never rendered as `[object Object]`.
- Constrained the currency rate note to a compact two-line display to protect the keypad area on narrow Android screens.
- Advanced the PWA cache namespace and added focused regression tests for count accuracy, provider labels and refresh placement.


## v1.92.7-v92 currency interaction refinement (2026-11-13)

- Dedicated Swap now exchanges both currency codes and both displayed raw amount values, preserving the conversion pair instead of retaining the old source amount.
- Destination amount is now explicitly accessible/editable as a decimal textbox, matching the existing two-way keypad calculation path.
- Added regression coverage for pair-swap value preservation, destination editability and reverse-input calculation.
- Rate sources remain public reference-rate feeds; these are not guaranteed bank, card, cash-exchange or remittance execution quotes.
- Restored visible, accessible provider status and refresh timestamps; the prior CSS override had hidden those diagnostics even though the app continued updating them.

## v1.92.7-v92 startup micro-audit (2026-11-14)

- Removed duplicate cache restoration from the DOM-ready sequence; the currency initializer remains the sole startup owner.
- Corrected the picker catalogue comment to match the fixed 105-currency implementation and provider-key exclusion behavior.
- Added a regression test for the single cache-restore path.
- Advanced app/package/manifest/UI/service-worker release identity to `1.92.7-v92`.


## v1.92.7-v92 localization layer (2026-11-14)

- Added `assets/js/localization.js` and loaded it before the app runtime.
- Added a shared phrase catalogue with 101 entries translated into Hindi, Urdu, Spanish, French, German, Arabic and Chinese, alongside English source text.
- Applies translations to matching static/dynamic text, select options, accessibility labels, titles and placeholders.
- Added RTL document direction for Urdu/Arabic, locale-aware numeric-only text/keypad/result glyphs and locale-specific currency refresh timestamps. Canonical keypad action values and calculation state remain ASCII.
- Added localization asset to service-worker precache and advanced cache identity.
- Regression suite: 78/78 passed.
- Limitation: unmatched UI strings still fall back to English; full translation coverage and Android/Acode visual QA remain outstanding.

## v1.94.0 localization rebuild verification (2026-11-14)

- Expanded localization catalogue: 628 keys / 4,396 non-English values.
- Static HTML text and accessibility/placeholder inventory: 400 entries, zero unaccounted ordinary-language strings.
- Unit Converter labels: 76/76 translated for all seven non-English languages.
- Currency display-name fallback: 105/105 selectable currency codes across all eight locales.
- Dynamic message templates now cover calculator display/accessibility, date countdown plurals, currency status, history, loan schedule, unit-price comparison and settings confirmations.
- RTL support expanded for Urdu and Arabic while preserving LTR mathematical expressions/keypads.
- Automated suite: 100/100 passed; JavaScript syntax checks passed; HTTP server returned 200 OK.
- Browser visual testing was blocked by the environment; native-speaker review and physical Android/Acode testing remain open release gates.

## v1.94.0 basic calculator, tools, settings and history polish (2026-11-14)

Source-level regression fixes:
- Reject malformed adjacent numeric literals such as `1..2` instead of silently treating them as implicit multiplication.
- Support documented constant adjacency such as `pi2`, `2pi2`, and `e2` while preserving scientific notation such as `2e3`.
- Ignore exponent signs when deriving the repeat-equals operation (`1e-3` no longer creates a false `- 3` repeat operation).
- Reset transient calculator result/repeat/scientific-continuation state when recalling memory.
- Map the Settings `heavy` vibration option to its intended 50 ms vibration, retaining `strong` as a saved-preference compatibility alias.
- Added focused regression coverage for precedence, unary signs, parentheses, percentages, implicit multiplication, constants, scientific notation, trig modes, factorial/range errors, malformed numbers, repeat-equals and memory/haptic state.

Verification: run `npm test` for the full suite. This is source-level and headless browser verification, not a guarantee of zero defects on every Android device.

## v1.94.0-v94 basic calculator and tools deep polish

- Corrected malformed numeric token adjacency, constant implicit multiplication, scientific-notation repeat-equals detection, memory-recall transient state, Strong/Heavy haptic duration and below-absolute-zero temperature conversions.
- Added expanded calculator parser, repeat-equals, trig-mode, percent, memory/haptic, loan zero-rate/grace, leap-day recurrence, Kelvin boundary and weighted-GPA regression cases.
- Current source-level test count is recorded in `RELEASE-VERIFICATION.md`; physical Android/Acode visual and interaction testing remains outstanding.


## v1.97.2-v97.2 — 14-Nov recording follow-up

- Reviewed the actual Android recording uploaded on 14-Nov, including the committed `8.337478 × 10¹⁷` result and the subsequent scientific-function interaction.
- Root cause: successful scientific-key insertion set a forced preview-error flag, overriding a valid parser result. This made a valid radical such as `√(8.337478 × 10¹⁷)` display `Error`.
- Fixed scientific-key preview to use the shared evaluator; committed-result scientific actions now apply to the visible committed answer. Full-precision raw values survive scientific display-token wrapping.
- Added seven focused regression tests; complete suite: **115 passed, 0 failed, 0 skipped**.
- `9^999` and `9^9999` remain out-of-range in the current IEEE-754 Number engine; no arbitrary-precision engine is claimed.
- Physical Android/Acode replay after installing this ZIP is still required to validate actual device behavior.

## v1.97.2-v97.2 — Error preview row stability
- Fixed error-state row reflow: error preview keeps the ordinary preview lane's height and alignment.
- Error text now uses the exact font size measured by the same preview fitting routine as successful preview values; error color remains the only intended visual distinction.
- Added regression tests for normal/error typography parity and stable row geometry.
- Full automated suite: 118/118 passing. Physical Android WebView verification remains pending.

## v1.97.2-v97.2 — Error preview row stability
- Fixed error-state row reflow: error preview keeps the ordinary preview lane's height and alignment.
- Error text now uses the exact font size measured by the same preview fitting routine as successful preview values; error color remains the only intended visual distinction.
- Added regression tests for normal/error typography parity and stable row geometry.
- Full automated suite: 118/118 passing. Physical Android WebView verification remains pending.

## v1.97.2-v97.2 server symlink boundary regression (2026-11-14)

- Added canonical real-path containment to the static server so symlinks cannot expose files outside the application root.
- Added a live HTTP regression test for the external-symlink case; temporary test files are cleaned up in a `finally` block.
- Full automated suite: **119 passed, 0 failed, 0 skipped**.
- Physical Android WebView / Acode validation, screen-reader testing, live currency-provider uptime and real-device performance remain manual release gates.


## v1.97.4-v97.4 — memory and parenthesized scientific-root integrity (2026-11-14)

- Added runtime regression coverage for MC/MR/MS/M+/M−, persistence, empty/corrupt storage, invalid inputs, and recall-state cleanup.
- Fixed parenthesized radical powers such as `∛(9^966)` and `√(9^324)` so a finite final root is evaluated without first overflowing the radicand.
- Added regression coverage for compact and parenthesized radical forms, overflow boundaries, and live preview.
- Bumped the app and service-worker cache version to prevent stale scripts from masking the fix.


## v1.97.5-v97.5 — exponent-marker regression
- Removed Euler-constant interpretation from the calculator `e` key and parser.
- Added coverage for bare `e` rejection and `e20`, `e+20`, `e-20`, `2e20` numeric parsing.


## v1.97.9-v97.9 — recording-driven Error row stability

- Source-level recording audit found a 48–76px live Error row and a separate 30px committed-error row conflicting with the normal 32px preview lane.
- Normal/live-error preview geometry unified at 32px; committed Error secondary lane collapsed to match the JS result-mode contract.
- Regression suite: 133/133 passed. JavaScript syntax: 22 files passed. CSS parse: 2,384 top-level rules, 0 parse errors. HTML: 231 unique IDs, 0 duplicates. Local assets: 0 missing. HTTP smoke: 4 endpoints returned 200.
- Physical Android WebView testing remains outstanding.


## v1.97.9-v97.9 — scientific continuation preview consistency (2026-11-14)
- Fixed a recording-reproduced mismatch where a committed scientific result such as `1×10⁹` remained scientific in the expression row after an operator was pressed, but the secondary live-preview row reverted to locale-grouped decimal (`1,00,00,00,000`).
- `formatCalculatorExpressionResult()` now recognizes a scientific display token anywhere in the active expression and uses the shared scientific display formatter for the preview/result value.
- Exact numeric evaluation and `STATE.calcRawValue` / `STATE.calcScientificContinuation` remain authoritative; only presentation formatting is kept consistent.
- Added regression coverage for `1×10⁹×` → `1×10⁹`, `1×10⁹×2` → `2×10⁹`, and `1×10⁹+2` → `1.000000002×10⁹`.
