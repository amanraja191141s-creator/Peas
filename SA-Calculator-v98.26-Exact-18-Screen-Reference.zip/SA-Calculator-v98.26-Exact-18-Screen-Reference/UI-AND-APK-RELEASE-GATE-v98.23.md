# v98.23 — Reference UI and APK release gate

## Design carried forward
The implementation retains the user's dark-native 4×2 reference direction:
- dark navy app canvas and compact dark app bars;
- calculator display with a four-column keypad and blue operator/action keys;
- categorized slide-out tool drawer and four-item bottom navigation;
- compact dark input cards, bright blue primary actions and green result cards;
- reference layouts for Sales Tax, Loan/EMI, Tip, Unit Price, World Time and Settings;
- remaining registered tools and their existing calculation engines retained.

## v98.23 release identity safeguards
- package/runtime/HTML/PWA manifest versions are pinned to `1.98.23-v98.23`;
- Android `versionCode` is `1098023` and the workflow checks the built APK's package metadata;
- service-worker cache namespace advanced to `sa-calculator-v98-23-reference-native-dark`;
- workflow fails if it selects any stale root or archive instead of the exact v98.23 source;
- all workflow copies are byte-identical.

## Local verification
- Node regression suite: 185 passed, 0 failed;
- JavaScript syntax checks: passed;
- YAML parsing: all 3 workflow copies parsed;
- workflow parity: passed;
- source/www web-bundle parity: passed;
- duplicate HTML IDs: 0;
- Android web bundle preparation: passed.

## Not yet verified
This environment did not run the GitHub-hosted Android Gradle build or install the APK on a physical phone. The earlier supplied phone recording showed About → Version `v1.98.19-v98.19`; it is not evidence of v98.22 or v98.23. Final pixel comparison must be done with the v98.23 APK installed and the About version checked.
